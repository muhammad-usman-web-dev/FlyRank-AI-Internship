 "use client";

import { ContactShadows, Environment, Float, OrbitControls } from "@react-three/drei";
import { Canvas, useFrame } from "@react-three/fiber";
import { Suspense, useRef } from "react";
import * as THREE from "three";
import type { ProductColor } from "@/lib/product";

type SceneProps = {
  color: ProductColor;
  autoRotate: boolean;
  metalness: number;
  roughness: number;
};

function Product({ color, autoRotate, metalness, roughness }: SceneProps) {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (group.current && autoRotate) {
      group.current.rotation.y += delta * 0.55;
    }
  });

  return (
    <Float speed={1.1} rotationIntensity={0.12} floatIntensity={0.18}>
      <group ref={group} rotation={[0.08, -0.45, 0]}>
        {/* Low-poly procedural product: no external model download is required. */}
        <mesh castShadow receiveShadow>
          <roundedBoxGeometry args={[2.7, 1.25, 1.5, 6, 0.18]} />
          <meshStandardMaterial color={color} metalness={metalness} roughness={roughness} />
        </mesh>

        <mesh position={[0, 0.78, 0]} castShadow>
          <roundedBoxGeometry args={[1.7, 0.22, 1.05, 6, 0.08]} />
          <meshStandardMaterial color="#e9edf3" metalness={0.45} roughness={0.28} />
        </mesh>

        <mesh position={[0, 0.92, 0]} castShadow>
          <cylinderGeometry args={[0.29, 0.29, 0.13, 32]} />
          <meshStandardMaterial color="#111318" metalness={0.7} roughness={0.2} />
        </mesh>

        <mesh position={[0, -0.74, 0]} receiveShadow>
          <boxGeometry args={[2.05, 0.12, 1.0]} />
          <meshStandardMaterial color="#0d0f12" metalness={0.15} roughness={0.72} />
        </mesh>

        {[-0.9, 0.9].map((x) => (
          <mesh key={x} position={[x, -0.87, 0]} receiveShadow>
            <cylinderGeometry args={[0.16, 0.16, 0.08, 24]} />
            <meshStandardMaterial color="#050607" roughness={0.75} />
          </mesh>
        ))}
      </group>
    </Float>
  );
}

export default function ProductScene(props: SceneProps) {
  return (
    <Canvas
      dpr={[1, 1.5]}
      camera={{ position: [4.5, 2.7, 5.2], fov: 38 }}
      shadows
      gl={{ antialias: true, powerPreference: "high-performance" }}
      fallback={null}
    >
      <color attach="background" args={["#f4f5f7"]} />
      <ambientLight intensity={0.65} />
      <directionalLight position={[4, 6, 3]} intensity={2.1} castShadow shadow-mapSize={[1024, 1024]} />
      <directionalLight position={[-4, 2, -2]} intensity={0.55} />
      <Suspense fallback={null}>
        <Environment preset="city" />
        <Product {...props} />
        <ContactShadows position={[0, -0.96, 0]} opacity={0.24} scale={7} blur={2.4} far={3} />
      </Suspense>
      <OrbitControls
        enablePan={false}
        minDistance={3.8}
        maxDistance={7.2}
        minPolarAngle={Math.PI * 0.28}
        maxPolarAngle={Math.PI * 0.68}
        enableDamping
        dampingFactor={0.07}
      />
    </Canvas>
  );
}
